#!/bin/bash

BASEDIR=`dirname $0`

LD_LIBRARY_PATH=/usr/local/lib mono $BASEDIR/ArduiPi_OLED_Wrapper.Test/bin/Debug/ArduiPi_OLED_Wrapper.Test.exe

