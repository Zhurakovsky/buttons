#!/bin/bash

BASEDIR=`dirname $0`

LD_LIBRARY_PATH=/usr/local/lib mono $BASEDIR/ArduiPi_OLED_Monitor/bin/Debug/BananaPiOLEDMonitor.exe

